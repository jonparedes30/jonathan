from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.contrib import messages
from empresa.models import Empresa

User = get_user_model()  # Usa tu modelo personalizado

# Iniciar sesión
def login_usuario(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('resumen_financiero')
        else:
            messages.error(request, 'Credenciales inválidas')
    return render(request, 'empresa/login.html')

# Cerrar sesión
def logout_usuario(request):
    logout(request)
    return redirect('login')

# Registro de usuario + empresa
def registrar_usuario(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        nombre_empresa = request.POST.get('nombre_empresa')
        ruc = request.POST.get('ruc')
        direccion = request.POST.get('direccion')

        # Validaciones
        if User.objects.filter(username=username).exists():
            messages.error(request, 'El nombre de usuario ya está en uso.')
        elif User.objects.filter(email=email).exists():
            messages.error(request, 'Ya existe una cuenta con ese correo.')
        elif Empresa.objects.filter(ruc=ruc).exists():
            messages.error(request, 'Ya existe una empresa registrada con ese RUC.')
        else:
            # Crear la empresa
            empresa = Empresa.objects.create(
                nombre=nombre_empresa,
                ruc=ruc,
                direccion=direccion
            )

            # Crear el usuario vinculado a esa empresa
            usuario = User.objects.create_user(
                username=username,
                password=password,
                email=email,
                empresa=empresa
            )
            usuario.save()
            messages.success(request, 'Cuenta y empresa creadas exitosamente. Ahora puedes iniciar sesión.')
            return redirect('login')

    return render(request, 'empresa/registro.html')
