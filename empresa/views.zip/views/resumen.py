# empresa/views/resumen.py

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from empresa.models import Venta, Compra, Gasto
from django.db.models import Sum
from datetime import datetime

@login_required
def resumen_financiero(request):
    empresa = request.user.empresa
    ventas = Venta.objects.filter(empresa=empresa).aggregate(total=Sum('monto'))['total'] or 0
    compras = Compra.objects.filter(empresa=empresa).aggregate(total=Sum('monto'))['total'] or 0
    gastos = Gasto.objects.filter(empresa=empresa).aggregate(total=Sum('monto'))['total'] or 0

    utilidad_bruta = ventas - compras
    utilidad_neta = utilidad_bruta - gastos

    contexto = {
        'ventas': ventas,
        'compras': compras,
        'gastos': gastos,
        'utilidad_bruta': utilidad_bruta,
        'utilidad_neta': utilidad_neta,
    }
    return render(request, 'empresa/resumen_financiero.html', contexto)

@login_required
def estado_resultados(request):
    empresa = request.user.empresa
    ventas = Venta.objects.filter(empresa=empresa).aggregate(Sum('monto'))['monto__sum'] or 0
    compras = Compra.objects.filter(empresa=empresa).aggregate(Sum('monto'))['monto__sum'] or 0
    gastos = Gasto.objects.filter(empresa=empresa).aggregate(Sum('monto'))['monto__sum'] or 0

    utilidad_operativa = ventas - compras
    utilidad_neta = utilidad_operativa - gastos

    contexto = {
        'ventas': ventas,
        'compras': compras,
        'gastos': gastos,
        'utilidad_operativa': utilidad_operativa,
        'utilidad_neta': utilidad_neta,
    }
    return render(request, 'empresa/estado_resultado.html', contexto)

@login_required
def flujo_caja(request):
    empresa = request.user.empresa
    hoy = datetime.today()
    año_actual = hoy.year
    meses = range(1, 13)

    flujo = []
    for mes in meses:
        ventas_mes = Venta.objects.filter(empresa=empresa, fecha__year=año_actual, fecha__month=mes).aggregate(Sum('monto'))['monto__sum'] or 0
        compras_mes = Compra.objects.filter(empresa=empresa, fecha__year=año_actual, fecha__month=mes).aggregate(Sum('monto'))['monto__sum'] or 0
        gastos_mes = Gasto.objects.filter(empresa=empresa, fecha__year=año_actual, fecha__month=mes).aggregate(Sum('monto'))['monto__sum'] or 0

        entrada = ventas_mes
        salida = compras_mes + gastos_mes
        neto = entrada - salida

        flujo.append({
            'mes': mes,
            'entrada': entrada,
            'salida': salida,
            'neto': neto
        })

    return render(request, 'empresa/flujo_caja.html', {'flujo': flujo})
