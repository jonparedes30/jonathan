# empresa/views/cuentas_contables.py

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from empresa.forms import CuentaContableForm
from empresa.models import CuentaContable
from django.contrib import messages

@login_required
def crear_cuenta_contable(request):
    if request.method == 'POST':
        form = CuentaContableForm(request.POST)
        if form.is_valid():
            cuenta = form.save(commit=False)
            cuenta.empresa = request.user.empresa
            cuenta.save()
            messages.success(request, 'Cuenta contable creada correctamente.')
            return redirect('dashboard')
    else:
        form = CuentaContableForm()
    return render(request, 'empresa/crear_cuenta_contable.html', {'form': form})
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from empresa.models import CuentaContable

@login_required
def listar_cuentas_contables(request):
    empresa = request.user.empresa
    cuentas = CuentaContable.objects.filter(empresa=empresa).order_by('nombre')
    return render(request, 'empresa/listar_cuentas_contables.html', {'cuentas': cuentas})
