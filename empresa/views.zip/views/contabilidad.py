from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from empresa.models import Venta, Compra, Gasto, CuentaContable, MovimientoContable

# ======================
# ESTADO DE RESULTADOS
# ======================
@login_required
def estado_resultados(request):
    empresa = request.user.empresa

    total_ventas = Venta.objects.filter(empresa=empresa).aggregate(total=Sum('monto'))['total'] or 0

    compras = Compra.objects.filter(empresa=empresa)
    total_costos = sum(c.precio_unitario * c.cantidad for c in compras)

    total_gastos = Gasto.objects.filter(empresa=empresa).aggregate(total=Sum('monto'))['total'] or 0

    utilidad_operativa = total_ventas - total_costos
    utilidad_neta = utilidad_operativa - total_gastos

    return render(request, 'empresa/estado_resultado.html', {
        'ventas': total_ventas,
        'costos': total_costos,
        'gastos': total_gastos,
        'utilidad_operativa': utilidad_operativa,
        'utilidad_neta': utilidad_neta,
    })

# ======================
# FLUJO DE CAJA ESTIMADO
# ======================
@login_required
def flujo_caja(request):
    empresa = request.user.empresa

    ventas = Venta.objects.filter(empresa=empresa)
    compras = Compra.objects.filter(empresa=empresa)
    gastos = Gasto.objects.filter(empresa=empresa)

    meses = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic']

    flujo = []
    for mes in range(1, 13):
        ventas_mes = ventas.filter(fecha__month=mes).aggregate(total=Sum('monto'))['total'] or 0
        compras_mes = compras.filter(fecha__month=mes).aggregate(total=Sum('precio_unitario'))['total'] or 0
        gastos_mes = gastos.filter(fecha__month=mes).aggregate(total=Sum('monto'))['total'] or 0

        entradas = ventas_mes
        salidas = compras_mes + gastos_mes
        neto = entradas - salidas

        flujo.append({
            'mes': meses[mes - 1],
            'entradas': entradas,
            'salidas': salidas,
            'neto': neto
        })

    return render(request, 'empresa/flujo_caja.html', {'flujo': flujo})


@login_required
def balance_general(request):
    return render(request, 'empresa/balance_general.html')


# ======================
# REGISTRO DE MOVIMIENTOS
# ======================
def registrar_movimiento_contable(empresa, cuenta_nombre, monto, descripcion, tipo='debito', tipo_cuenta='activo'):
    cuenta, _ = CuentaContable.objects.get_or_create(
        empresa=empresa,
        nombre__icontains=cuenta_nombre,
        defaults={'nombre': cuenta_nombre, 'tipo': tipo_cuenta}
    )

    MovimientoContable.objects.create(
        empresa=empresa,
        cuenta=cuenta,
        tipo=tipo,
        monto=monto,
        descripcion=descripcion
    )
