# empresa/views/compras.py

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from empresa.models import Compra
from empresa.forms import CompraForm

@login_required
def crear_compra(request):
    empresa = request.user.empresa

    if request.method == 'POST':
        form = CompraForm(request.POST, empresa=empresa)
        if form.is_valid():
            compra = form.save(commit=False)
            compra.empresa = empresa
            compra.save()
            return redirect('listar_compras')
    else:
        form = CompraForm(empresa=empresa)

    return render(request, 'empresa/crear_compra.html', {'form': form})


@login_required
def listar_compras(request):
    empresa = request.user.empresa
    compras = Compra.objects.filter(empresa=empresa).order_by('-fecha')
    return render(request, 'empresa/listar_compras.html', {'compras': compras})
