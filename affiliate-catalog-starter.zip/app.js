
async function loadProducts(){
  const res = await fetch('./data/products.json');
  const data = await res.json();
  window._all = data.products;
  initFilters(data.products);
  render(data.products);
}
function initFilters(products){
  const cat = document.getElementById('cat');
  const store = document.getElementById('store');
  const cats = Array.from(new Set(products.map(p => p.category))).filter(Boolean).sort();
  const stores = Array.from(new Set(products.map(p => p.store))).filter(Boolean).sort();
  cats.forEach(c => { const o=document.createElement('option'); o.value=c; o.textContent=c; cat.appendChild(o); });
  stores.forEach(s => { const o=document.createElement('option'); o.value=s; o.textContent=s; store.appendChild(o); });
  ['q','cat','store','sort'].forEach(id => document.getElementById(id).addEventListener('input', applyFilters));
}
function applyFilters(){
  let list = [...window._all];
  const q = document.getElementById('q').value.toLowerCase();
  const cat = document.getElementById('cat').value;
  const store = document.getElementById('store').value;
  const sort = document.getElementById('sort').value;
  if(q) list = list.filter(p => (p.title + ' ' + (p.category||'') + ' ' + (p.store||'')).toLowerCase().includes(q));
  if(cat) list = list.filter(p => p.category === cat);
  if(store) list = list.filter(p => p.store === store);
  if(sort === 'price_asc') list.sort((a,b)=> (a.price||999999) - (b.price||999999));
  if(sort === 'price_desc') list.sort((a,b)=> (b.price||-1) - (a.price||-1));
  if(sort === 'rating_desc') list.sort((a,b)=> (b.rating||0) - (a.rating||0));
  render(list);
}
function render(list){
  const grid = document.getElementById('grid');
  grid.innerHTML = '';
  list.forEach(p => {
    const card = document.createElement('div');
    card.className = 'card';
    const img = document.createElement('img');
    img.src = p.image || 'https://via.placeholder.com/600x400?text=Producto';
    img.alt = p.title;
    const pad = document.createElement('div');
    pad.className = 'pad';
    const title = document.createElement('div');
    title.textContent = p.title;
    const badges = document.createElement('div'); badges.className = 'badges';
    if(p.store){ const b = document.createElement('span'); b.className='badge'; b.textContent=p.store; badges.appendChild(b); }
    if(p.category){ const b = document.createElement('span'); b.className='badge'; b.textContent=p.category; badges.appendChild(b); }
    if(p.rating){ const b = document.createElement('span'); b.className='badge'; b.textContent='★ ' + p.rating; badges.appendChild(b); }
    const price = document.createElement('div'); price.className='price'; price.textContent = p.price ? ('$' + p.price.toFixed(2)) : 'Ver precio en la tienda';
    const btn = document.createElement('a'); btn.className='btn'; btn.target='_blank'; btn.rel='nofollow sponsored noopener';
    btn.href = p.url; btn.textContent = 'Ver en la tienda →';
    pad.appendChild(title); pad.appendChild(badges); pad.appendChild(price); pad.appendChild(btn);
    card.appendChild(img); card.appendChild(pad); grid.appendChild(card);
  });
}
loadProducts();
