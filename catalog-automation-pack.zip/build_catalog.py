#!/usr/bin/env python3
# build_catalog.py
#
# Genera/actualiza data/products.json con resultados de APIs (eBay Browse API por ahora).
# Lee credenciales de variables de entorno para no exponer claves en el repo.
#
# Requisitos:
#   - pip install requests
#   - Secrets en GitHub: EBAY_CLIENT_ID, EBAY_CLIENT_SECRET (production)
#
# Notas:
#   - El feed que generamos lo consume tu frontend estático (index.html + app.js).
#   - Skimlinks monetiza los enlaces al hacer clic, no necesitas tocar los URLs.
#   - Respeta rate limits: limitamos resultados y queries.
import os, sys, time, json, base64, requests
from datetime import datetime, timezone

OUTPUT_PATH = "data/products.json"

# ---- Configurable ----
QUERIES = [
    # Tecnología
    ("Auriculares Bluetooth", "Tecnología"),
    ("Smartwatch", "Tecnología"),
    ("Altavoz Bluetooth", "Audio"),
    ("TV 55 4K", "TV & Video"),
    ("Laptop 14 i5", "Computadoras"),
    ("Cámara DSLR", "Fotografía"),
    # Hogar y otros
    ("Robot vacuum", "Hogar"),
    ("Desk lamp LED", "Hogar"),
    ("Zapatillas running", "Moda"),
]

PER_QUERY_LIMIT = 6   # máximo por búsqueda
GLOBAL_MAX = 60       # corte de seguridad
ENV = os.getenv("EBAY_ENV", "production")  # 'production' o 'sandbox'
SITE = os.getenv("EBAY_SITE", "EBAY_US")   # mercado (EBAY_US, EBAY_GB, EBAY_DE...)

def get_ebay_oauth_token():
    client_id = os.environ.get("EBAY_CLIENT_ID")
    client_secret = os.environ.get("EBAY_CLIENT_SECRET")
    if not client_id or not client_secret:
        print("ERROR: Falta EBAY_CLIENT_ID o EBAY_CLIENT_SECRET", file=sys.stderr)
        sys.exit(1)
    token_url = "https://api.ebay.com/identity/v1/oauth2/token" if ENV == "production" else "https://api.sandbox.ebay.com/identity/v1/oauth2/token"
    auth = (client_id, client_secret)
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    data = {
        "grant_type": "client_credentials",
        "scope": "https://api.ebay.com/oauth/api_scope"
    }
    r = requests.post(token_url, data=data, headers=headers, auth=auth, timeout=20)
    r.raise_for_status()
    tok = r.json()
    return tok["access_token"], int(tok["expires_in"])

def ebay_search(query, limit=10):
    token, _ = get_ebay_oauth_token()
    url = "https://api.ebay.com/buy/browse/v1/item_summary/search"
    params = {
        "q": query,
        "limit": str(limit),
        "fieldgroups": "EXTENDED",
        "sort": "price",
        "X-EBAY-C-MARKETPLACE-ID": SITE
    }
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "X-EBAY-C-MARKETPLACE-ID": SITE
    }
    r = requests.get(url, params=params, headers=headers, timeout=25)
    r.raise_for_status()
    return r.json()

def normalize_ebay(item, category):
    # Campos seguros con defaults
    title = item.get("title") or "Producto eBay"
    web_url = item.get("itemWebUrl") or item.get("item_web_url") or ""
    price_obj = item.get("price") or {}
    amount = None
    currency = None
    if isinstance(price_obj, dict):
        amount = float(price_obj.get("value")) if price_obj.get("value") is not None else None
        currency = price_obj.get("currency")
    image = None
    if item.get("image") and item["image"].get("imageUrl"):
        image = item["image"]["imageUrl"]
    elif item.get("thumbnailImages"):
        image = item["thumbnailImages"][0].get("imageUrl")
    rating = None  # eBay Browse no siempre da rating del producto
    return {
        "title": title,
        "store": "eBay",
        "category": category,
        "price": amount,
        "currency": currency or "USD",
        "rating": rating,
        "image": image,
        "url": web_url
    }

def build():
    products = []
    seen_urls = set()
    for q, cat in QUERIES:
        try:
            data = ebay_search(q, limit=PER_QUERY_LIMIT)
            for it in data.get("itemSummaries", []):
                p = normalize_ebay(it, cat)
                if not p["url"] or p["url"] in seen_urls:
                    continue
                seen_urls.add(p["url"])
                products.append(p)
                if len(products) >= GLOBAL_MAX:
                    break
            if len(products) >= GLOBAL_MAX:
                break
            time.sleep(0.7)  # ser amable con rate limits
        except requests.HTTPError as e:
            print(f"HTTPError en búsqueda '{q}': {e}", file=sys.stderr)
        except Exception as e:
            print(f"Error en búsqueda '{q}': {e}", file=sys.stderr)

    # Cargar existente para conservar si no hay resultados
    if os.path.exists(OUTPUT_PATH):
        try:
            with open(OUTPUT_PATH, "r", encoding="utf-8") as f:
                existing = json.load(f)
        except Exception:
            existing = {"products": []}
    else:
        existing = {"products": []}

    if products:
        out = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "source": "eBay Browse API",
            "products": products
        }
    else:
        print("Advertencia: no se obtuvieron productos nuevos; se mantiene el archivo existente.", file=sys.stderr)
        out = existing

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(f"Escrito {OUTPUT_PATH} con {len(out.get('products', []))} productos.")

if __name__ == "__main__":
    build()
