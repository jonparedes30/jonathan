# Catálogo automático (eBay → JSON) para tu sitio estático

Este paquete añade **catálogo automático** a tu sitio GitHub Pages:
- Un script `build_catalog.py` consulta **eBay Browse API** por palabras clave y guarda `data/products.json`.
- Un workflow de **GitHub Actions** lo ejecuta **cada hora** y hace commit del archivo actualizado.
- Tu frontend estático (index.html + app.js) lee ese JSON y se actualiza **solo**.

> Monetización: Deja el **script de Skimlinks** en tus páginas. Los enlaces `itemWebUrl` de eBay se convertirán en afiliados al hacer clic.

## Requisitos
1. Repo con tu frontend (ya tienes `index.html`, `app.js`, `data/`).
2. Cuenta de **eBay Developers** y credenciales **(Client ID/Secret)** en producción.
3. Habilitar **GitHub Actions** (está por defecto).

## Instalación (5 pasos)
1. Copia `build_catalog.py` a la **raíz del repo**.
2. Crea carpeta `.github/workflows/` (si no existe) y coloca `build-catalog.yml` dentro.
3. En tu repo, ve a **Settings → Secrets and variables → Actions → New repository secret** y agrega:
   - `EBAY_CLIENT_ID`
   - `EBAY_CLIENT_SECRET`
4. Asegúrate de tener `data/` (y `data/products.json` inicial, aunque sea vacío `{ "products": [] }`).  
5. Ve a **Actions** y ejecuta **Run workflow** (o espera a la corrida programada).

## ¿Dónde se ven los cambios?
El script sobrescribe `data/products.json`. Tu **frontend** debe pedirlo (ej.: `fetch('./data/products.json')`) y renderizar las tarjetas.

## Cambiar consultas / categorías
Edita `QUERIES` en `build_catalog.py`. Ejemplo:
```python
QUERIES = [
  ("wireless earbuds", "Tecnología"),
  ("smartwatch", "Tecnología"),
  ("robot vacuum", "Hogar"),
]
```
`PER_QUERY_LIMIT` y `GLOBAL_MAX` controlan cuántos productos trae.

## Notas de cumplimiento
- **Rate limits**: se hace `sleep(0.7)` entre búsquedas; ajusta según tu uso.
- **Amazon PA-API**: si la integras más adelante, respeta su regla de **cache ≤ 24 h** y muestra timestamp.
- **Skimlinks**: mantén el script en todas las páginas (antes de `</body>`).

## Extender a otras fuentes
- **Amazon PA-API**: usa el SDK oficial paapi5 y normaliza a la misma estructura.
- **AliExpress/Walmart/BestBuy**: añade conectores con sus APIs (si requieres).

¡Listo! Con esto tu catálogo se actualiza automáticamente sin servidores.
